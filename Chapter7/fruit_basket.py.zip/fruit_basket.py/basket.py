#!/usr/bin/env python3

"""calculate the price of a fruit gift basket"""

__author__ = 'Kennedy Bittinger'
__date__ = '3/4/24'

import pathlib
import csv


def read_prices(price_file):
    """Read prices from a file.

    Args:
        price_file (str): name of the price file

    Returns:
        prices (list): list of prices
    """
    prices = []
    if pathlib.Path(price_file).exists():
        with open(price_file, 'r') as file_handle:
            prices = [float(line.strip()) for line in file_handle]
    return prices


def calculate_total(prices, order_file):
    """Calculate the total cost of a basket.

    Args:
        prices (list): list of prices
        order_file (str): name of the order file

    Returns:
        total (float): total cost of the basket
    """
    total = 0
    if pathlib.Path(order_file).exists():
        with open(order_file, 'r') as file_handle:
            reader = csv.reader(file_handle)
            for line in reader:
                item_num, quantity = map(int, line)
                total += prices[item_num] * quantity
    return total


def main():
    """Main function to calculate the total cost of a basket."""
    price_file = input("Price file? ")
    print()
    order_file = input("Basket file? ")
    print()

    try:
        prices = read_prices(price_file)
        total = calculate_total(prices, order_file)
        print(f"Basket will cost ${total:.2f}".rstrip('0').rstrip('.'))
        print()
    except FileNotFoundError:
        print("File not found.")


if __name__ == "__main__":
    main()
