#!/usr/bin/env python 3

"""Write a program to read and total all numbers in a file"""

__author__ = 'Kennedy Bittinger'
__date__ = '3/10/2024'


import sys


def total_numbers(file_name):
    """Read and total all numbers from a file.

    Args:
        file_name (str): Name of the file to read.

    Returns:
        total (float): Sum of all numbers in the file.
    """
    total = 0
    try:
        with open(file_name, 'r') as in_file:
            for line in in_file:
                for num_str in line.split():
                    try:
                        num = float(num_str)
                        total += num
                    except ValueError:
                        print(f'Invalid number: {num_str}')
    except OSError:
        print('Could not open file - exiting')
        sys.exit()

    return total


def main():
    """Main function."""
    file_name = input('File? ')
    print()
    total = total_numbers(file_name)
    print(f'Grand total: {total}')


if __name__ == '__main__':
    main()
