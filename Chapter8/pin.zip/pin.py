#!/usr/bin/env python3

"""Module to check pin against a pin file."""

__author__ = 'Kennedy Bittinger'
__date__ = '3/10/24'

import sys

NUM_ATTEMPTS = 3


def read_pin(file_name):
    """Read the pin from pin file.

    Args:
        None

    Returns:
        pin (int) : read from file
    """
    line = ''
    try:
        with open(file_name, 'r') as in_file:
            line = in_file.readline()
    except OSError:
        print('Could not open file - exiting')
        sys.exit()
    return int(line)


def main():
    """Check if pin is correct.

    Args:
        None

    Returns:
        None
    """
    pin_file = input('Pin file? ')
    print()
    pin = read_pin(pin_file)
    guess = pin - 1

    counter = 0
    while counter < NUM_ATTEMPTS and pin != guess:
        try:
            guess = int(input('Pin? '))
            print()
            counter += 1
        except ValueError:
            print('Pin is an integer')
    if pin != guess:
        print('Denied')
    else:
        print('Access Granted')


if __name__ == '__main__':
    main()
