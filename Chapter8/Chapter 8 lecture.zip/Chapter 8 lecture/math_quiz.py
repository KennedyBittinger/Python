#!/usr/bin/env python3

"""Module to present a simple math quiz."""

__author__ = 'Kennedy Bittinger'
__date__ = '6/16/2020'

import csv
import sys


def bad_stuff():
    """Demonstrate more exception skills.

    Args:
        None

    Returns:
        None
    """
    file_name = input('File? ')
    print()
    try:
        # Note: pylint/pycodestyle may suggest using with
        #       We did not do it here so we could easily practice a
        #       variety of exceptions and nested try statements
        in_file = open(file_name, 'r')
        try:
            count = 0
            for line in in_file:
                print(line, end='')
                count += 1
            if count < 5:
                # Force an exception if the file is small
                raise OSError('File too small')
        except OSError as err:
            # print the type of the err object, space, and
            # -- the message associated with err
            print(type(err), err)
        finally:
            # finally always executes whether there was an exception
            # or not - usually has clean-up code
            in_file.close()
    except FileNotFoundError as err:
        print(err)
    # Will force a ValueError
    num = int('abc')
    print(num)


def main():
    """Present a simple math quiz.

    Args:
        None

    Returns:
        None
    """
    file_name = input('File? ')
    print()

    try:
        with open(file_name, 'r', newline='') as in_file:
            reader = csv.reader(in_file)
            for row in reader:
                # Remember row is a list of the comma separated values
                # on one line
                num1 = int(row[0])
                num2 = int(row[1])
                operator = row[2]

                if operator == '+':
                    ans = num1 + num2
                elif operator == '-':
                    ans = num1 - num2
                elif operator == '*':
                    ans = num1 * num2
                elif operator == '/':
                    ans = num1 // num2

                try:
                    guess = int(input('What is '
                                      + row[0] + row[2] + row[1]
                                      + '? '))
                    print()

                    if ans == guess:
                        print('Yay!')
                    else:
                        print('Sorry, it is ' + str(ans))
                except ValueError:
                    print('Your input is not an integer')
    except FileNotFoundError as err:
        print(err)
        sys.exit()
    except OSError:
        print('Error reading file ' + file_name)
        sys.exit()
    print('Bye!')
    try:
        bad_stuff()
    except ValueError:
        print('function passed back ValueError')


if __name__ == '__main__':
    main()
